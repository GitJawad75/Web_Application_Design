const cities = {
  Dhaka: {
    accommodation: [
      { name: "Pan Pacific Sonargaon",info:  "it offers fine dining, modern amenities, and warm hospitality.",
         rating: 5, base: 100, image: "images/hotel1.jpg" },
      { name: "Hotel 71", rating: 3, base: 50, image: "images/hotel2.jpg" },
      { name: "Radisson Blu", rating: 4, base: 80, image: "images/hotel3.jpg" }
    ],
    places: [
      { name: "Lalbagh Fort",about: "An Old Fort Of Mughals empire .", price: 5, image: "images/place1.jpg" },
      { name: "Ahsan Manzil",about: "An Old Fort Of Mughals empire .", price: 4, image: "images/place2.jpg" },
      { name: "Hatirjheel",about: "An Old Fort Of Mughals empire .", price: 3, image: "images/place3.jpg" }
    ],
    marketplace: [
      { name: "Bashundhara City", items: "Fashion, Electronics", image: "images/market1.jpg" },
      { name: "New Market", items: "Local goods, Books", image: "images/market2.jpg" },
      { name: "Jamuna Future Park", items: "Luxury, Cinema, Food Court", image: "images/market3.jpg" }
    ]
  },
  Istanbul: {
    accommodation: [
      { name: "Ramada Plaza", rating: 5, base: 120, image: "images/hotel4.jpg" },
      { name: "Grand Faith", rating: 3, base: 60, image: "images/hotel5.jpg" },
      { name: "The Marmara Taksim", rating: 4, base: 90, image: "images/hotel6.jpg" }
    ],
    places: [
      { name: "Galata Tower",about: "An Old Fort Of Mughals empire .", price: 7, image: "images/place4.jpg" },
      { name: "Blue Mosque",about: "An Old Fort Of Mughals empire .", price: 0, image: "images/place5.jpg" },
      { name: "Topkapi Palace",about: "An Old Fort Of Mughals empire .", price: 8, image: "images/place6.jpg" }
    ],
    marketplace: [
      { name: "Istinye Park", items: "Luxury Brands", image: "images/market4.jpg" },
      { name: "Grand Bazaar", items: "Handicrafts, Jewelry", image: "images/market5.jpg" },
      { name: "Spice Bazaar", items: "Spices, Sweets", image: "images/market6.jpg" }
    ]
  },
  Kathmandu: {
    accommodation: [
      { name: "Hyatt Regency", rating: 5, base: 110, image: "images/hotel7.jpg" },
      { name: "Yak & Yeti", rating: 4, base: 85, image: "images/hotel8.jpg" },
      { name: "Fairfield Marriott", rating: 3, base: 70, image: "images/hotel9.jpg" }
    ],
    places: [
      { name: "Swayambhunath",about: "An Old Fort Of Mughals empire .", price: 4, image: "images/place7.jpg" },
      { name: "Pashupatinath",about: "An Old Fort Of Mughals empire .", price: 3, image: "images/place8.jpg" },
      { name: "Durbar Square",about: "An Old Fort Of Mughals empire .", price: 5, image: "images/place9.jpg" }
    ],
    marketplace: [
      { name: "Thamel Market", items: "Souvenirs, Gear", image: "images/market7.jpg" },
      { name: "Durbar Market", items: "Antiques, Art", image: "images/market8.jpg" },
      { name: "Asan Bazaar", items: "Spices, Local Goods", image: "images/market9.jpg" }
    ]
  }
};

  
  let currentCity = "";
  
  // Animations for Landing Page
  document.addEventListener("DOMContentLoaded", () => {
    anime.timeline()
      .add({
        targets: '.animate-title',
        opacity: [0, 1],
        translateY: [50, 0],
        easing: 'easeOutExpo',
        duration: 1000
      })
      .add({
        targets: '.animate-subtitle',
        opacity: [0, 1],
        translateY: [30, 0],
        easing: 'easeOutExpo',
        duration: 800,
        offset: '-=600'
      })
      .add({
        targets: '.animate-form',
        opacity: [0, 1],
        scale: [0.8, 1],
        easing: 'easeOutExpo',
        duration: 800,
        offset: '-=600'
      })
      .add({
        targets: '.social-icon',
        opacity: [0, 1],
        translateY: [20, 0],
        easing: 'easeOutExpo',
        duration: 600,
        delay: anime.stagger(100)
      });
  });
  
  // Signup Form Submission
  document.getElementById("signup-form").addEventListener("submit", function(e) {
    e.preventDefault();
    anime({
      targets: '.landing-page',
      opacity: 0,
      translateY: -50,
      easing: 'easeInOutQuad',
      duration: 500,
      complete: () => {
        document.querySelector(".landing-page").classList.add("hidden");
        document.querySelector(".city-selection").classList.remove("hidden");
        anime({
          targets: '.animate-city-title',
          opacity: [0, 1],
          translateY: [30, 0],
          easing: 'easeOutExpo',
          duration: 800
        });
        anime({
          targets: '.btn-city',
          opacity: [0, 1],
          translateY: [50, 0],
          easing: 'easeOutExpo',
          duration: 800,
          delay: anime.stagger(200)
        });
      }
    });
  });
  
  // Select City
  function selectCity(city) {
    currentCity = city;
    anime({
      targets: '.city-selection',
      opacity: 0,
      translateY: -50,
      easing: 'easeInOutQuad',
      duration: 500,
      complete: () => {
        document.querySelector(".city-selection").classList.add("hidden");
        document.querySelector(".service-selection").classList.remove("hidden");
        document.getElementById("selected-city").textContent = `Services in ${city}`;
        anime({
          targets: '.animate-service-title',
          opacity: [0, 1],
          translateY: [30, 0],
          easing: 'easeOutExpo',
          duration: 800
        });
        anime({
          targets: '.btn-service',
          opacity: [0, 1],
          scale: [0.8, 1],
          easing: 'easeOutExpo',
          duration: 800,
          delay: anime.stagger(200)
        });
      }
    });
  }
  
  // Load Service
  function loadService(type) {
    const container = document.getElementById("service-content");
    container.classList.remove("hidden");
    container.innerHTML = `<h2 class="text-center mb-4">${type.toUpperCase()}</h2><div class="grid"></div>`;
    const grid = container.querySelector(".grid");
  
    if (type === "accommodation") {
      cities[currentCity][type].forEach(hotel => {
        const card = document.createElement("div");
        card.className = "card";
        card.innerHTML = `
          <img src="${hotel.image}" alt="${hotel.name}" class="img-fluid rounded-top" style="height: 200px; object-fit: cover;">
          <h3>${hotel.name}</h3>
          <p>${hotel.info}</p>
          <div class="stars">${"★".repeat(hotel.rating)}</div>
          <p>Base: $${hotel.base}</p>
          <label class="d-block"><input type="checkbox" onchange="updatePrice(this, ${hotel.base}, 10)"> +TV ($10)</label>
          <label class="d-block"><input type="checkbox" onchange="updatePrice(this, ${hotel.base}, 20)"> +POOL ($20)</label>
          <label class="d-block"><input type="checkbox" onchange="updatePrice(this, ${hotel.base}, 25)"> +AC ($25)</label>
          <strong>Total: $<span class="price">${hotel.base}</span></strong>
        `;
        grid.appendChild(card);
      });
    }
  
    if (type === "places") {
      cities[currentCity][type].forEach(place => {
        const card = document.createElement("div");
        card.className = "card";
        card.innerHTML = `
          <img src="${place.image}" alt="${place.name}" class="img-fluid rounded-top" style="height: 200px; object-fit: cover;">
          <h3>${place.name}</h3>
          <p>${place.about}</p>
          <p>Ticket: $${place.price}</p>
          <div>
            <button class="ticket-btn" onclick="adjustTickets(this, ${place.price}, -1)">-</button>
            <span class="ticket-count">0</span>
            <button class="ticket-btn" onclick="adjustTickets(this, ${place.price}, 1)">+</button>
          </div>
          <strong>Total: $<span class="price">0</span></strong>
        `;
        grid.appendChild(card);
      });
    }
  
    if (type === "marketplace") {
      cities[currentCity][type].forEach(market => {
        const card = document.createElement("div");
        card.className = "card";
        card.innerHTML = `
          <img src="${market.image}" alt="${market.name}" class="img-fluid rounded-top" style="height: 200px; object-fit: cover;">
          <h3>${market.name}</h3>
          <p>Available: ${market.items}</p>
        `;
        grid.appendChild(card);
      });
    }
  
    // Animate cards
    anime({
      targets: '.card',
      opacity: [0, 1],
      translateY: [50, 0],
      easing: 'easeOutExpo',
      duration: 800,
      delay: anime.stagger(100)
    });
  }
  
  // Update Price for Accommodation
  function updatePrice(checkbox, base, addon) {
    const card = checkbox.closest(".card");
    const priceTag = card.querySelector(".price");
    let price = parseInt(priceTag.textContent);
    price += checkbox.checked ? addon : -addon;
    priceTag.textContent = price;
    anime({
      targets: priceTag,
      scale: [1.2, 1],
      easing: 'easeOutElastic(1, .6)',
      duration: 500
    });
  }
  
  // Adjust Tickets for Places
 // Adjust Tickets for Places
function adjustTickets(button, price, change) {
  const card = button.closest(".card"); // Fix: use closest to get full card
  const countSpan = card.querySelector(".ticket-count");
  let count = parseInt(countSpan.textContent) + change;
  if (count < 0) count = 0;
  countSpan.textContent = count;

  const total = count * price;
  const priceTag = card.querySelector(".price");
  priceTag.textContent = total;

  anime({
    targets: [countSpan, priceTag],
    scale: [1.2, 1],
    easing: 'easeOutElastic(1, .6)',
    duration: 500
  });
}
